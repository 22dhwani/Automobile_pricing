package auto;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;
import java.util.Set;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebCrawler {
    private Set<String> visitedUrls;
    private Queue<String> urlsToVisit;
    private int maxUrlsToVisit;
    private String saveDir;
    
    public WebCrawler(int maxUrlsToVisit, String saveDir) {
        visitedUrls = new HashSet<String>();
        urlsToVisit = new LinkedList<String>();
        this.maxUrlsToVisit = maxUrlsToVisit;
        this.saveDir = saveDir;
    }
    
    public void clear() {
        visitedUrls.clear();
        urlsToVisit.clear();
    }

    public void crawl(String startingUrl, String saveDir) throws IOException {
        File dir = new File(saveDir);
        if (!dir.exists()) {
            dir.mkdir();
        }
        urlsToVisit.add(startingUrl);
        while (!urlsToVisit.isEmpty() && visitedUrls.size() < maxUrlsToVisit) {
            String url = urlsToVisit.poll();
            if (!visitedUrls.contains(url)) {
                visitedUrls.add(url);
                System.out.println("Visiting: " + url);
                String links = HTMLParser.parse(url, saveDir);
                for (String nextUrl : links.split(" ")) {
                    if (!visitedUrls.contains(nextUrl)) {
                        urlsToVisit.add(nextUrl);
                    }
                }
            }
        }
        System.out.println("Website is crawled!");
    }
    
    public static void main(String[] args) throws IOException {
        int maxUrlsToVisit = 15;
        String saveDir = "pages";
        
        HashMap<String, Integer> wordFreqMap = new HashMap<>();
        
        WebCrawler crawler = new WebCrawler(maxUrlsToVisit, saveDir);
        InvertedIndex index = new InvertedIndex();
        PageRanking pageRanking = new PageRanking();
        FrequencyCount freqCount = new FrequencyCount();
        CarPriceScrapper priceScrapper = new CarPriceScrapper();

        Scanner scanner = new Scanner(System.in);
        int option;

        do {
            System.out.println("\n1: Crawl website");
            System.out.println("2: Scrap car brands according to Price");
            System.out.println("3: Scrap car brands according to MPG");
            System.out.println("4: Inverted indexing");
            System.out.println("5: Frequency count");
            System.out.println("6: Page ranking");
            System.out.println("7: Spell checking");
            System.out.println("8: Spell suggestion");
            System.out.println("9: Search words frequency");
            System.out.println("0: Terminate\n");
            
            System.out.println("Enter Value: ");
            option = scanner.nextInt();
            scanner.nextLine();

            switch (option) {
                case 1:
                    String startingUrl;
                    do {
                        System.out.print("Enter a starting URL: ");
                        startingUrl = scanner.nextLine();
                        
                        if (!UrlValidator.validate(startingUrl)) {
                            System.out.println("Invalid URL. Please try again.");
                        }
                    } while (!UrlValidator.validate(startingUrl));
                    crawler.clear();
                    crawler.crawl(startingUrl, saveDir);
                    break;
                    
                case 2:
                	Scanner priceScanner = new Scanner(System.in);
                	
                	System.out.print("Enter car name: ");
                    String carNamePrice = priceScanner.nextLine();
                    System.out.print("Enter min. price: ");
                    int minPrice = priceScanner.nextInt();
                    System.out.print("Enter max. price: ");
                    int maxPrice = priceScanner.nextInt();
                    System.out.println();

                    try {
                    	priceScrapper.ScrapCarPriceData(carNamePrice, minPrice, maxPrice);
                    } catch (IOException e) {
                        System.out.println("An error occurred while scraping car data.");
                        e.printStackTrace();
                    }
                    break;
                    
                case 3:
                	
                	CarMpgScrapper carScrapper = new CarMpgScrapper();
                	
                	Scanner carScanner = new Scanner(System.in);

            		// Prompt the user to enter the URL of the website to scrape
            		System.out.print("Enter the name of the Car: ");
            		String carName = carScanner.nextLine();
            		
            		if (wordFreqMap.containsKey(carName)) {
                        wordFreqMap.put(carName, wordFreqMap.get(carName) + 1);
                    } else {
                        wordFreqMap.put(carName, 1);
                    }

            		// Prompt the user to enter the year of the cars to scrape
            		System.out.print("Enter the year of the cars to scrape: ");
            		int year = carScanner.nextInt();

            		// Prompt the user to enter the mileage range to sort by
            		System.out.print("Enter the minimum mileage (mpg): ");
            		int minMpg = carScanner.nextInt();
            		System.out.print("Enter the maximum mileage (mpg): ");
            		int maxMpg = carScanner.nextInt();
            		System.out.println();

            		// Scrape the car data and print the sorted results
            		carScrapper.scrapMileage(carName, year, minMpg, maxMpg);                    
                    break;

                case 4:
                	
                	Scanner indexScanner = new Scanner(System.in);
                	
                    index.buildIndex("/Users/meghpatel/eclipse-workspace/Automobile_pricing/pages/");
                    
                    System.out.println("Enter the keyword to search: ");
                    String keyword = indexScanner.nextLine();
                    index.searchKeyword(keyword);
                    break;

                case 5:
                    freqCount.countFrequency("/Users/meghpatel/eclipse-workspace/Automobile_pricing/pages/");
                    break;
                    
                case 6:
                    pageRanking.PageRank("/Users/meghpatel/eclipse-workspace/Automobile_pricing/pages/");
                    break;
                    
                case 7:
                	// Read text files and build dictionary trie
                    SpellChecker spellChecker = new SpellChecker();
                    String folderPath = "/Users/meghpatel/eclipse-workspace/Automobile_pricing/pages/";
                    spellChecker.readTextFilesAndBuildDictionary(folderPath);

                    // Prompt user to input string for spell checking
                    Scanner spellScanner = new Scanner(System.in);
                    System.out.println("Enter a string to check for spelling errors:");
                    String input = spellScanner.nextLine();
                    
                    if (wordFreqMap.containsKey(input)) {
                        wordFreqMap.put(input, wordFreqMap.get(input) + 1);
                    } else {
                        wordFreqMap.put(input, 1);
                    }

                    // Spell check the input and print the result
                    String output = spellChecker.spellCheck(input);
                    System.out.println("Spell checked string:");
                    System.out.println(output);
                    break;
                    
                case 8:
                	SpellSuggestion spellSuggestion = new SpellSuggestion("/Users/meghpatel/eclipse-workspace/Automobile_pricing/pages/");
                	
                	Scanner suggestionScanner = new Scanner(System.in);
                    System.out.println("Enter a word to check for suggestions:");
                    String word = suggestionScanner.nextLine();
                    
                    if (wordFreqMap.containsKey(word)) {
                        wordFreqMap.put(word, wordFreqMap.get(word) + 1);
                    } else {
                        wordFreqMap.put(word, 1);
                    }
                    
                    String suggestion = spellSuggestion.suggestWord(word);
                    if (suggestion.isEmpty()) {
                        System.out.println("No suggestions found for " + word);
                    } else {
                        System.out.println("Did you mean " + suggestion + " ?");
                    }
                    break;
                    
                case 9:
                	ArrayList<Map.Entry<String, Integer>> list = new ArrayList<>(wordFreqMap.entrySet());
                	Collections.sort(list, Map.Entry.<String, Integer>comparingByValue().reversed());

                	System.out.println("Word Frequencies (Descending Order): ");
                	for (Map.Entry<String, Integer> entry : list) {
                	    System.out.println(entry.getKey() + ": " + entry.getValue());
                	}
                	break;


                case 0:
                	System.out.println("Thank you!");
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        } while (option != 0);
    }

}